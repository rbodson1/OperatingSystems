#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/slab.h>
struct birthday
{
int day, month, year; // declaring day, month and year
char *name, *gender; // declaring name and gender
struct list_head list;
};
// initializing birthday_list object
static LIST_HEAD(birthday_list);
struct birthday *student;
struct birthday *next;
struct birthday *compare;

int simple_init(void)
{
printk(KERN_INFO "Loading Module\n");
printk(KERN_INFO "Name Gender Month Day Year\n");
/* initializing name,gender,day,month and year for the students */
student = kmalloc(sizeof(*student), GFP_KERNEL); // allocating memory
student->name = "Rachid";
student->gender = "Male";
student->day = 02;
student->month = 02;
student->year = 1995;
INIT_LIST_HEAD(&student->list);
list_add_tail(&student->list, &birthday_list);

student = kmalloc(sizeof(*student), GFP_KERNEL);
student->name = "Bodson";
student->gender = "Male";
student->day = 10;
student->month = 05;
student->year = 1998;
INIT_LIST_HEAD(&student->list);
list_add_tail(&student->list, &birthday_list);

student = kmalloc(sizeof(*student), GFP_KERNEL);
student->name = "Pam";
student->gender = "Female";
student->day = 18;
student->month = 11;
student->year = 1997;
INIT_LIST_HEAD(&student->list);
list_add_tail(&student->list, &birthday_list);

student = kmalloc(sizeof(*student), GFP_KERNEL);
student->name = "Rita";
student->gender = "Female";
student->day = 04;
student->month = 12;
student->year = 1998;
INIT_LIST_HEAD(&student->list);
list_add_tail(&student->list, &birthday_list);

student = kmalloc(sizeof(*student), GFP_KERNEL);
student->name = "Alain";
student->gender = "Male";
student->day = 07;
student->month = 10;
student->year = 2000;
INIT_LIST_HEAD(&student->list);
list_add_tail(&student->list, &birthday_list);

compare = kmalloc(sizeof(*compare), GFP_KERNEL);
compare->year = 2000;
compare->gender = "Male";

list_for_each_entry(student, &birthday_list, list) {
printk(KERN_INFO "%s '%s' %d-%d-%d", student->name, student-> gender, student->month, student->day, student->year);
}


// Deleting the youngest male student
list_for_each_entry_safe(student,next,&birthday_list,list) {
if(student->year >= compare->year && student->gender == compare->gender){ // comparing to find the youngest male
printk(KERN_INFO "\nStudent deleted is %s", student->name);
list_del(&student->list);
kfree(student);
}
}

//Outputting the updated list
printk(KERN_INFO "\nUpdated list\n");
list_for_each_entry(student, &birthday_list, list) {
printk(KERN_INFO "%s '%s' %d-%d-%d", student->name, student-> gender, student->month, student->day, student->year);
}


return 0;
}
void simple_exit(void)
{

// Deleting the updated list
printk(KERN_INFO "\nRemoving Module\n");
list_for_each_entry_safe(student,next,&birthday_list,list) {
printk(KERN_INFO "%s '%s' %d-%d-%d", student->name, student-> gender, student->month, student->day, student->year);
list_del(&student->list);
kfree(student);
}
}
module_init(simple_init);
module_exit(simple_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Kernel Data Structures");
MODULE_AUTHOR("SGG");
